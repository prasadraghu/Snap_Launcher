# Snap launcher
Swipe up = all apps/search. Swipe left = News. Swipe right = Widgets.
1. github.com > New repository > "uploading an existing file" > drag in everything from this folder (incl. .github) > Commit.
2. Actions tab > "Build APK" (~4 min) > open the run > Artifacts > snap-launcher-apk.
3. Unzip, install the APK. Settings > Apps > Default apps > Home app > Snap.
