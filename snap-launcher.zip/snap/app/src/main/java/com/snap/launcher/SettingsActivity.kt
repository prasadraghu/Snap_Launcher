package com.snap.launcher

import android.content.res.Configuration
import android.graphics.Color
import android.os.Bundle
import android.view.View
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import androidx.activity.ComponentActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.widget.doAfterTextChanged

class SettingsActivity : ComponentActivity() {
    private lateinit var store: Store
    private var fg = Color.WHITE
    private var sub = 0
    private var chipBg = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        store = Store(this)
        val night = when (store.theme) { 1 -> true; 2 -> false; else -> (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES }
        fg = if (night) Color.WHITE else 0xFF14151A.toInt()
        sub = if (night) 0xA6FFFFFF.toInt() else 0x99000000.toInt()
        chipBg = if (night) 0x26FFFFFF else 0x14000000
        val scroll = ScrollView(this).apply { setBackgroundColor(if (night) 0xFF101114.toInt() else 0xFFF6F7FB.toInt()) }
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(12), dp(20), dp(32)) }
        scroll.addView(col)
        ViewCompat.setOnApplyWindowInsetsListener(scroll) { v, i ->
            val b = i.getInsets(WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout())
            v.setPadding(b.left, b.top, b.right, b.bottom); i
        }
        setContentView(scroll)
        WindowCompat.getInsetsController(window, scroll).apply { isAppearanceLightStatusBars = !night; isAppearanceLightNavigationBars = !night }

        col.label("Snap settings", 26f, 8)
        col.label("Theme", 14f, 16, sub)
        col.choice(listOf("System", "Dark", "Light"), store.theme) { store.theme = it }
        col.label("Accent colour", 14f, 16, sub)
        col.swatches()
        col.label("Home grid columns", 14f, 16, sub)
        col.choice(listOf("3", "4", "5", "6"), store.columns - 3) { store.columns = it + 3 }
        col.label("Icon size", 14f, 16, sub)
        col.slider(36, 72, store.iconDp) { store.iconDp = it }
        col.toggle("Show app labels on Home", store.showLabels) { store.showLabels = it }
        col.toggle("Open keyboard when swiping up", store.keyboardOnSwipe) { store.keyboardOnSwipe = it }
        col.toggle("Auto tags (Games, Social, Music…)", store.autoTags) { store.autoTags = it }
        col.toggle("Also pull Google News for each tracked topic", store.gnews) { store.gnews = it }
        col.label("Web search URL", 14f, 16, sub)
        col.addView(EditText(this).apply { setText(store.searchUrl); setTextColor(fg); setSingleLine(); doAfterTextChanged { store.searchUrl = it.toString() } })
        col.button("Ask for contacts/files permission again") { store.askedPerms = false }
        col.button("Unhide all apps (${store.hidden.size} hidden)") { store.hidden = emptySet(); recreate() }
        col.label("Tips: long-press an app to pin, tag or hide it. In search, long-press a tag chip to put it on Home. Type #tag to filter. Press Enter to open the top result.", 13f, 20, sub)
    }

    private fun LinearLayout.label(t: String, size: Float, top: Int, color: Int = fg) =
        addView(TextView(context).apply { text = t; textSize = size; setTextColor(color); setPadding(0, dp(top), 0, dp(4)) })

    private fun LinearLayout.choice(opts: List<String>, sel: Int, pick: (Int) -> Unit) {
        val row = LinearLayout(context)
        opts.forEachIndexed { i, o ->
            row.addView(TextView(context).apply {
                text = o; textSize = 14f; setPadding(dp(16), dp(10), dp(16), dp(10))
                setTextColor(if (i == sel) 0xFF101114.toInt() else fg)
                background = pill(if (i == sel) store.accent else chipBg, dp(20))
                layoutParams = LinearLayout.LayoutParams(WRAP, WRAP).apply { marginEnd = dp(8) }
                setOnClickListener { pick(i); recreate() }
            })
        }
        addView(row)
    }

    private fun LinearLayout.swatches() {
        val row = LinearLayout(context)
        for (c in listOf(0xFF7C9CFF, 0xFFFF7A7A, 0xFF6EE7B7, 0xFFFFC857, 0xFFC792EA, 0xFFFFFFFF)) {
            row.addView(View(context).apply {
                background = pill(c.toInt(), dp(20))
                layoutParams = LinearLayout.LayoutParams(dp(40), dp(40)).apply { marginEnd = dp(10) }
                setOnClickListener { store.accent = c.toInt(); recreate() }
            })
        }
        addView(row)
    }

    private fun LinearLayout.toggle(t: String, on: Boolean, change: (Boolean) -> Unit) {
        addView(Switch(context).apply { text = t; isChecked = on; textSize = 15f; setTextColor(fg); setPadding(0, dp(12), 0, dp(12)); setOnCheckedChangeListener { _, v -> change(v) } })
    }

    private fun LinearLayout.slider(min: Int, maxV: Int, value: Int, change: (Int) -> Unit) {
        addView(SeekBar(context).apply {
            max = maxV - min; progress = value - min
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) { if (fromUser) change(p + min) }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        })
    }

    private fun LinearLayout.button(t: String, click: () -> Unit) {
        addView(TextView(context).apply {
            text = t; textSize = 14f; setTextColor(fg); background = pill(chipBg, dp(20)); setPadding(dp(16), dp(12), dp(16), dp(12))
            layoutParams = LinearLayout.LayoutParams(WRAP, WRAP).apply { topMargin = dp(12) }
            setOnClickListener { click() }
        })
    }
}
