package com.snap.launcher

import android.net.Uri
import android.text.Html
import android.util.Xml
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import org.json.JSONArray
import org.json.JSONObject
import org.xmlpull.v1.XmlPullParser
import java.io.StringReader
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Locale

data class Article(val title: String, val link: String, val source: String, val time: Long, val desc: String, val topic: String?)

object News {
    private fun http(url: String): String? = try {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 8000; c.readTimeout = 8000; c.instanceFollowRedirects = true
        c.setRequestProperty("User-Agent", "Mozilla/5.0 (Android) Snap")
        c.inputStream.bufferedReader().use { it.readText() }
    } catch (e: Exception) { null }

    private fun isFeed(b: String) = b.take(800).lowercase().let { it.contains("<rss") || it.contains("<feed") }

    fun discover(input: String): String? {
        var u = input.trim(); if (u.isEmpty()) return null
        if (!u.startsWith("http")) u = "https://$u"
        val body = http(u) ?: return null
        if (isFeed(body)) return u
        try {
            val tag = Regex("<link[^>]+type=[\"']application/(rss|atom)\\+xml[\"'][^>]*>", RegexOption.IGNORE_CASE).find(body)?.value
            val href = tag?.let { Regex("href=[\"']([^\"']+)[\"']").find(it)?.groupValues?.get(1) }
            if (href != null) return URL(URL(u), href).toString()
            for (p in listOf("/feed", "/rss", "/rss.xml", "/feed.xml")) {
                val c = URL(URL(u), p).toString()
                val b = http(c)
                if (b != null && isFeed(b)) return c
            }
        } catch (e: Exception) { }
        return null
    }

    private val fmts = listOf("EEE, dd MMM yyyy HH:mm:ss zzz", "EEE, dd MMM yyyy HH:mm:ss Z", "yyyy-MM-dd'T'HH:mm:ssXXX", "yyyy-MM-dd'T'HH:mm:ss'Z'")
    private fun date(s: String): Long {
        for (f in fmts) { try { return SimpleDateFormat(f, Locale.US).parse(s.trim())!!.time } catch (e: Exception) { } }
        return 0L
    }
    private fun clean(s: String): String = try { Html.fromHtml(s.take(600), 0).toString().trim().take(300) } catch (e: Exception) { "" }

    fun parse(xml: String, source: String, topic: String?): List<Article> {
        val out = ArrayList<Article>()
        try {
            val p = Xml.newPullParser(); p.setInput(StringReader(xml.trim().trimStart('\uFEFF')))
            var ev = p.eventType
            var inItem = false
            var t = ""; var l = ""; var d = ""; var tm = 0L
            while (ev != XmlPullParser.END_DOCUMENT) {
                if (ev == XmlPullParser.START_TAG) {
                    val n = p.name
                    if (n == "item" || n == "entry") { inItem = true; t = ""; l = ""; d = ""; tm = 0L }
                    else if (inItem) {
                        when (n) {
                            "title" -> t = clean(p.nextText())
                            "link" -> { val h = p.getAttributeValue(null, "href"); val x = p.nextText().trim(); if (l.isEmpty()) l = h ?: x }
                            "description", "summary" -> d = clean(p.nextText())
                            "pubDate", "updated", "published" -> tm = date(p.nextText())
                        }
                    }
                } else if (ev == XmlPullParser.END_TAG && (p.name == "item" || p.name == "entry") && inItem) {
                    inItem = false
                    if (t.isNotEmpty() && l.isNotEmpty()) out.add(Article(t, l, source, tm, d, topic))
                    if (out.size >= 40) break
                }
                ev = p.next()
            }
        } catch (e: Exception) { }
        return out
    }

    suspend fun fetchAll(store: Store): List<Article> = coroutineScope {
        val jobs = ArrayList<kotlinx.coroutines.Deferred<List<Article>>>()
        for (s in store.sites) jobs.add(async(Dispatchers.IO) {
            http(s)?.let { parse(it, Uri.parse(s).host?.removePrefix("www.") ?: s, null) } ?: emptyList()
        })
        if (store.gnews) for (t in store.topics) jobs.add(async(Dispatchers.IO) {
            http("https://news.google.com/rss/search?q=" + Uri.encode(t) + "&hl=en-IN&gl=IN&ceid=IN:en")?.let { parse(it, "Google News", t) } ?: emptyList()
        })
        jobs.awaitAll().flatten().distinctBy { it.link }.sortedByDescending { it.time }
    }

    fun forTopic(all: List<Article>, topic: String?): List<Article> {
        if (topic == null) return all
        val w = topic.lowercase().split(" ").filter { it.isNotEmpty() }
        return all.filter { it.topic == topic || (it.topic == null && w.all { x -> (it.title + " " + it.desc).lowercase().contains(x) }) }
    }

    fun toJson(l: List<Article>): String {
        val a = JSONArray()
        for (x in l.take(300)) a.put(JSONObject().put("t", x.title).put("l", x.link).put("s", x.source).put("m", x.time).put("d", x.desc).put("p", x.topic ?: ""))
        return a.toString()
    }
    fun fromJson(s: String): List<Article> = try {
        val a = JSONArray(s)
        List(a.length()) { val o = a.getJSONObject(it); Article(o.getString("t"), o.getString("l"), o.getString("s"), o.getLong("m"), o.getString("d"), o.getString("p").ifEmpty { null }) }
    } catch (e: Exception) { emptyList() }
}
