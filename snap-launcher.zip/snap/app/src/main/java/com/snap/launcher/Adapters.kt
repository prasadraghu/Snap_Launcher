package com.snap.launcher

import android.content.Context
import android.graphics.Color
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class ResultAdapter(
    private val ctx: Context, private val repo: AppRepo,
    private val onClick: (Row) -> Unit, private val onLong: (Row) -> Unit
) : RecyclerView.Adapter<ResultAdapter.VH>() {
    var items: List<Row> = emptyList()
        private set
    var textC = Color.WHITE
    var subC = 0xA6FFFFFF.toInt()
    var accent = 0xFF7C9CFF.toInt()

    fun submit(l: List<Row>) { items = l; notifyDataSetChanged() }
    override fun getItemCount() = items.size
    override fun getItemViewType(position: Int) = if (items[position] is Row.Header) 0 else 1

    class VH(val root: LinearLayout, val icon: ImageView, val glyph: TextView, val title: TextView, val sub: TextView) : RecyclerView.ViewHolder(root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val c = ctx
        val root = LinearLayout(c).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            layoutParams = RecyclerView.LayoutParams(MATCH, WRAP)
            setPadding(c.dp(20), c.dp(if (viewType == 0) 14 else 8), c.dp(20), c.dp(8))
        }
        if (viewType == 1) { val tv = TypedValue(); c.theme.resolveAttribute(android.R.attr.selectableItemBackground, tv, true); root.setBackgroundResource(tv.resourceId) }
        val icon = ImageView(c).apply { layoutParams = LinearLayout.LayoutParams(c.dp(44), c.dp(44)) }
        val glyph = TextView(c).apply {
            gravity = Gravity.CENTER; textSize = 18f; layoutParams = LinearLayout.LayoutParams(c.dp(44), c.dp(44))
            background = pill(0x33888888, c.dp(22))
        }
        val col = LinearLayout(c).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, WRAP, 1f).apply { marginStart = if (viewType == 0) 0 else c.dp(14) }
        }
        val title = TextView(c).apply { textSize = if (viewType == 0) 12f else 16f; maxLines = 2 }
        val sub = TextView(c).apply { textSize = 12f; maxLines = 1 }
        col.addView(title); col.addView(sub)
        root.addView(icon); root.addView(glyph); root.addView(col)
        return VH(root, icon, glyph, title, sub)
    }

    override fun onBindViewHolder(h: VH, pos: Int) {
        val r = items[pos]
        h.title.setTextColor(textC); h.sub.setTextColor(subC)
        h.icon.visibility = View.GONE; h.glyph.visibility = View.GONE; h.sub.visibility = View.VISIBLE
        var g = ""; var t = ""; var s = ""
        when (r) {
            is Row.Header -> { h.title.setTextColor(accent); h.title.text = r.title.uppercase(); h.sub.visibility = View.GONE; return }
            is Row.App -> { h.icon.visibility = View.VISIBLE; h.icon.setImageBitmap(repo.icon(r.app)); t = r.app.label; s = r.subtitle }
            is Row.Contact -> { g = "👤"; t = r.name; s = r.number }
            is Row.FileRow -> { g = "📄"; t = r.name; s = r.mime }
            is Row.Setting -> { g = "⚙"; t = r.title; s = "Settings" }
            is Row.Web -> { g = "🌐"; t = "Search the web for “${r.query}”" }
            is Row.News -> { g = "📰"; t = r.a.title; s = r.sub }
        }
        if (g.isNotEmpty()) { h.glyph.visibility = View.VISIBLE; h.glyph.text = g }
        h.title.text = t; h.sub.text = s
        if (s.isEmpty()) h.sub.visibility = View.GONE
        h.root.setOnClickListener { onClick(r) }
        h.root.setOnLongClickListener { onLong(r); true }
    }
}

class PinnedAdapter(
    private val ctx: Context, private val repo: AppRepo, private val store: Store,
    private val onClick: (AppEntry) -> Unit, private val onLong: (AppEntry) -> Unit
) : RecyclerView.Adapter<PinnedAdapter.VH>() {
    private var items: List<AppEntry> = emptyList()
    fun submit(l: List<AppEntry>) { items = l; notifyDataSetChanged() }
    override fun getItemCount() = items.size
    class VH(val root: LinearLayout, val icon: ImageView, val label: TextView) : RecyclerView.ViewHolder(root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val c = ctx
        val root = LinearLayout(c).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL; setPadding(0, c.dp(8), 0, c.dp(8)) }
        val icon = ImageView(c)
        val label = TextView(c).apply {
            textSize = 11f; maxLines = 1; gravity = Gravity.CENTER; setTextColor(Color.WHITE)
            setShadowLayer(4f, 0f, 1f, 0x80000000.toInt())
        }
        root.addView(icon); root.addView(label, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = c.dp(4) })
        return VH(root, icon, label)
    }

    override fun onBindViewHolder(h: VH, pos: Int) {
        val a = items[pos]
        h.icon.layoutParams = LinearLayout.LayoutParams(ctx.dp(store.iconDp), ctx.dp(store.iconDp))
        h.icon.setImageBitmap(repo.icon(a))
        h.label.text = a.label
        h.label.visibility = if (store.showLabels) View.VISIBLE else View.GONE
        h.root.setOnClickListener { onClick(a) }
        h.root.setOnLongClickListener { onLong(a); true }
    }
}
