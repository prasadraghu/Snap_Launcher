package com.snap.launcher

import android.Manifest
import android.app.AlertDialog
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.appwidget.AppWidgetHost
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProviderInfo
import android.content.res.Configuration
import android.text.format.DateUtils
import android.widget.ScrollView
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.GestureDetector
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.TextClock
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.widget.doAfterTextChanged
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.abs

class MainActivity : ComponentActivity() {
    private lateinit var store: Store
    private lateinit var repo: AppRepo
    private lateinit var search: Search
    private lateinit var root: FrameLayout
    private lateinit var home: LinearLayout
    private lateinit var homeTagScroll: HorizontalScrollView
    private lateinit var homeTagRow: LinearLayout
    private lateinit var pinHint: TextView
    private lateinit var pinnedRv: RecyclerView
    private lateinit var clock: TextClock
    private lateinit var dateView: TextClock
    private lateinit var panel: LinearLayout
    private lateinit var tagRow: LinearLayout
    private lateinit var resultsRv: RecyclerView
    private lateinit var bar: FrameLayout
    private lateinit var input: EditText
    private lateinit var pinnedAdapter: PinnedAdapter
    private lateinit var resultAdapter: ResultAdapter
    private lateinit var widgetsPage: LinearLayout
    private lateinit var widgetBox: LinearLayout
    private lateinit var widgetsHeader: LinearLayout
    private lateinit var newsPage: LinearLayout
    private lateinit var newsHeader: LinearLayout
    private lateinit var newsTabs: LinearLayout
    private lateinit var newsRv: RecyclerView
    private lateinit var newsAdapter: ResultAdapter
    private var page: View? = null
    private var articles: List<Article> = emptyList()
    private var newsTopic: String? = null
    private var pendingId = -1
    private val host by lazy { AppWidgetHost(this, 1024) }
    private val awm: AppWidgetManager by lazy { AppWidgetManager.getInstance(this) }

    private var activeTag: String? = null
    private var panelOpen = false
    private var searchJob: Job? = null
    private var night = true
    private var textC = Color.WHITE
    private var subC = 0
    private var chipBg = 0
    private var topI = 0; private var botI = 0; private var leftI = 0; private var rightI = 0

    private val permLauncher = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { runSearch() }
    private val pkgReceiver = object : BroadcastReceiver() { override fun onReceive(c: Context?, i: Intent?) { reload() } }
    private val swipe by lazy {
        GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onFling(e1: MotionEvent?, e2: MotionEvent, vx: Float, vy: Float): Boolean {
                if (e1 == null || panelOpen) return false
                val dx = e2.x - e1.x
                val dy = e1.y - e2.y
                if (abs(dx) > abs(dy)) {
                    if (abs(dx) < dp(80) || abs(vx) < 800f) return false
                    if (page == null) { if (dx < 0) showPage(newsPage) else showPage(widgetsPage) }
                    else if ((page === newsPage && dx > 0) || (page === widgetsPage && dx < 0)) closePage()
                    return true
                }
                if (page == null && dy > dp(80) && vy < -800f) { openSearch(store.keyboardOnSwipe); return true }
                return false
            }
        })
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        window.isNavigationBarContrastEnforced = false
        store = Store(this); repo = AppRepo(this); search = Search(this, repo, store)
        buildUi()
        setContentView(root)
        ViewCompat.setOnApplyWindowInsetsListener(root) { _, insets ->
            val b = insets.getInsets(WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout())
            val ime = insets.getInsets(WindowInsetsCompat.Type.ime())
            topI = b.top; leftI = b.left; rightI = b.right; botI = maxOf(b.bottom, ime.bottom)
            applyInsets()
            insets
        }
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() { if (panelOpen) closeSearch() else closePage() }
        })
        ContextCompat.registerReceiver(this, pkgReceiver, IntentFilter().apply {
            addAction(Intent.ACTION_PACKAGE_ADDED); addAction(Intent.ACTION_PACKAGE_REMOVED)
            addAction(Intent.ACTION_PACKAGE_CHANGED); addAction(Intent.ACTION_PACKAGE_REPLACED); addDataScheme("package")
        }, ContextCompat.RECEIVER_EXPORTED)
        reload()
    }

    override fun onDestroy() { super.onDestroy(); unregisterReceiver(pkgReceiver) }
    override fun onStart() { super.onStart(); try { host.startListening() } catch (e: Exception) { } }
    override fun onStop() { super.onStop(); try { host.stopListening() } catch (e: Exception) { } }

    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        if (req == 78 || req == 77) {
            if (res == RESULT_OK) { if (req == 78) configureOrAdd(pendingId) else addWidget(pendingId) }
            else host.deleteAppWidgetId(pendingId)
        }
    }

    override fun onResume() {
        super.onResume()
        applyTheme()
        pinnedRv.layoutManager = GridLayoutManager(this, store.columns)
        refreshAll()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        if (intent.hasCategory(Intent.CATEGORY_HOME)) { closeSearch(); closePage() }
    }

    override fun dispatchTouchEvent(ev: MotionEvent): Boolean { swipe.onTouchEvent(ev); return super.dispatchTouchEvent(ev) }

    private fun reload() { lifecycleScope.launch { withContext(Dispatchers.Default) { repo.load() }; refreshAll() } }

    private fun buildUi() {
        root = FrameLayout(this).apply { isFocusableInTouchMode = true }
        home = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(0x33000000); isLongClickable = true; setOnLongClickListener { homeMenu(); true } }
        clock = TextClock(this).apply { format12Hour = "h:mm"; format24Hour = "HH:mm"; textSize = 56f; setTextColor(Color.WHITE); typeface = Typeface.create("sans-serif-light", Typeface.NORMAL) }
        dateView = TextClock(this).apply { format12Hour = "EEE, d MMM"; format24Hour = "EEE, d MMM"; textSize = 16f; setTextColor(0xCCFFFFFF.toInt()) }
        home.addView(clock); home.addView(dateView)
        home.addView(View(this), LinearLayout.LayoutParams(MATCH, 0, 1f))
        pinHint = TextView(this).apply { text = "Swipe up or tap search, long-press an app, then “Pin to home”."; setTextColor(0xB3FFFFFF.toInt()); textSize = 13f; visibility = View.GONE }
        home.addView(pinHint)
        homeTagRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        homeTagScroll = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; addView(homeTagRow) }
        home.addView(homeTagScroll, LinearLayout.LayoutParams(MATCH, WRAP).apply { bottomMargin = dp(8) })
        pinnedAdapter = PinnedAdapter(this, repo, store, { launchApp(it) }, { appMenu(it) })
        pinnedRv = RecyclerView(this).apply { layoutManager = GridLayoutManager(this@MainActivity, store.columns); adapter = pinnedAdapter; overScrollMode = View.OVER_SCROLL_NEVER; isNestedScrollingEnabled = false }
        home.addView(pinnedRv, LinearLayout.LayoutParams(MATCH, WRAP))
        root.addView(home, FrameLayout.LayoutParams(MATCH, MATCH))

        widgetBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        widgetsPage = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; visibility = View.GONE; isClickable = true }
        widgetsHeader = pageHeader("Widgets", "＋ Add" to { addWidgetFlow() })
        widgetsPage.addView(widgetsHeader, LinearLayout.LayoutParams(MATCH, WRAP))
        widgetsPage.addView(ScrollView(this).apply { addView(widgetBox) }, LinearLayout.LayoutParams(MATCH, 0, 1f))
        root.addView(widgetsPage, FrameLayout.LayoutParams(MATCH, MATCH))

        newsTabs = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(dp(8), dp(4), 0, dp(8)) }
        newsAdapter = ResultAdapter(this, repo, { r -> if (r is Row.News) { try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(r.a.link))) } catch (e: Exception) { } } }, { })
        newsRv = RecyclerView(this).apply { layoutManager = LinearLayoutManager(this@MainActivity); adapter = newsAdapter; clipToPadding = false }
        newsPage = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; visibility = View.GONE; isClickable = true }
        newsHeader = pageHeader("News", "↻" to { refreshNews(true) }, "⋯" to { newsMenu() })
        newsPage.addView(newsHeader, LinearLayout.LayoutParams(MATCH, WRAP))
        newsPage.addView(HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; addView(newsTabs) }, LinearLayout.LayoutParams(MATCH, WRAP))
        newsPage.addView(newsRv, LinearLayout.LayoutParams(MATCH, 0, 1f))
        root.addView(newsPage, FrameLayout.LayoutParams(MATCH, MATCH))

        panel = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; visibility = View.GONE; isClickable = true }
        tagRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(dp(16), dp(8), dp(16), dp(8)) }
        panel.addView(HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; addView(tagRow) }, LinearLayout.LayoutParams(MATCH, WRAP))
        resultAdapter = ResultAdapter(this, repo, { open(it) }, { r -> if (r is Row.App) appMenu(r.app) })
        resultsRv = RecyclerView(this).apply { layoutManager = LinearLayoutManager(this@MainActivity); adapter = resultAdapter; clipToPadding = false }
        resultsRv.addOnScrollListener(object : RecyclerView.OnScrollListener() {
            override fun onScrollStateChanged(rv: RecyclerView, state: Int) {
                if (state == RecyclerView.SCROLL_STATE_DRAGGING) WindowCompat.getInsetsController(window, input).hide(WindowInsetsCompat.Type.ime())
            }
        })
        panel.addView(resultsRv, LinearLayout.LayoutParams(MATCH, 0, 1f))
        root.addView(panel, FrameLayout.LayoutParams(MATCH, MATCH))

        input = EditText(this).apply {
            hint = "Search apps, #tags, contacts, files…"; setSingleLine(); background = null
            imeOptions = EditorInfo.IME_ACTION_SEARCH
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
            textSize = 16f; setPadding(dp(22), 0, dp(22), 0)
        }
        input.doAfterTextChanged { if (!panelOpen && !it.isNullOrBlank()) openSearch(false) else if (panelOpen) runSearch() }
        input.setOnFocusChangeListener { _, f -> if (f && !panelOpen) openSearch(false) }
        input.setOnEditorActionListener { _, id, _ ->
            if (id == EditorInfo.IME_ACTION_SEARCH) { resultAdapter.items.firstOrNull { it !is Row.Header }?.let { open(it) }; true } else false
        }
        bar = FrameLayout(this).apply { addView(input, FrameLayout.LayoutParams(MATCH, MATCH)) }
        root.addView(bar, FrameLayout.LayoutParams(MATCH, dp(52), Gravity.BOTTOM))
    }

    private fun applyTheme() {
        night = when (store.theme) { 1 -> true; 2 -> false; else -> (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES }
        textC = if (night) Color.WHITE else 0xFF14151A.toInt()
        subC = if (night) 0xA6FFFFFF.toInt() else 0x99000000.toInt()
        chipBg = if (night) 0x26FFFFFF else 0x14000000
        val pbg = if (night) 0xF2101114.toInt() else 0xF2F6F7FB.toInt()
        panel.setBackgroundColor(pbg); widgetsPage.setBackgroundColor(pbg); newsPage.setBackgroundColor(pbg)
        styleHeader(widgetsHeader); styleHeader(newsHeader)
        newsAdapter.textC = textC; newsAdapter.subC = subC; newsAdapter.accent = store.accent
        bar.background = pill(if (night) 0xE61E2026.toInt() else 0xF2FFFFFF.toInt(), dp(26))
        input.setTextColor(textC); input.setHintTextColor(subC)
        resultAdapter.textC = textC; resultAdapter.subC = subC; resultAdapter.accent = store.accent
        updateBars()
    }

    private fun updateBars() {
        val c = WindowCompat.getInsetsController(window, root)
        c.isAppearanceLightStatusBars = (panelOpen || page != null) && !night
        c.isAppearanceLightNavigationBars = (panelOpen || page != null) && !night
    }

    private fun applyInsets() {
        val gap = dp(12); val barH = dp(52)
        (bar.layoutParams as FrameLayout.LayoutParams).apply { bottomMargin = botI + gap; leftMargin = leftI + dp(16); rightMargin = rightI + dp(16) }
        bar.requestLayout()
        home.setPadding(leftI + dp(24), topI + dp(32), rightI + dp(24), botI + gap * 2 + barH)
        panel.setPadding(leftI, topI, rightI, 0)
        resultsRv.setPadding(0, 0, 0, botI + gap * 2 + barH)
        for (p in listOf(widgetsPage, newsPage)) p.setPadding(leftI + dp(8), topI + dp(8), rightI + dp(8), botI + gap * 2 + barH)
    }

    private fun refreshAll() { refreshPinned(); refreshHomeTags(); refreshTagRow(); runSearch() }

    private fun refreshPinned() {
        val h = store.hidden
        val l = store.pinned.mapNotNull { repo.find(it) }.filter { it.key !in h }
        pinnedAdapter.submit(l)
        pinHint.visibility = if (l.isEmpty() && repo.apps.isNotEmpty()) View.VISIBLE else View.GONE
    }

    private fun chip(text: String, fg: Int, bg: Int, click: () -> Unit, long: (() -> Unit)? = null) = TextView(this).apply {
        this.text = text; textSize = 13f; setTextColor(fg); background = pill(bg, dp(20))
        setPadding(dp(14), dp(8), dp(14), dp(8))
        layoutParams = LinearLayout.LayoutParams(WRAP, WRAP).apply { marginEnd = dp(8) }
        setOnClickListener { click() }
        if (long != null) setOnLongClickListener { long(); true }
    }

    private fun refreshHomeTags() {
        homeTagRow.removeAllViews()
        val t = store.homeTags
        homeTagScroll.visibility = if (t.isEmpty()) View.GONE else View.VISIBLE
        for (x in t) homeTagRow.addView(chip("#$x", Color.WHITE, 0x40FFFFFF, { activeTag = x; openSearch(false) },
            { store.homeTags = store.homeTags - x; refreshHomeTags() }))
    }

    private fun refreshTagRow() {
        tagRow.removeAllViews()
        val dark = 0xFF101114.toInt()
        tagRow.addView(chip("All", if (activeTag == null) dark else textC, if (activeTag == null) store.accent else chipBg, { activeTag = null; refreshTagRow(); runSearch() }))
        for ((t, n) in search.allTags()) {
            val sel = activeTag == t
            tagRow.addView(chip("#$t · $n", if (sel) dark else textC, if (sel) store.accent else chipBg,
                { activeTag = if (sel) null else t; refreshTagRow(); runSearch() },
                {
                    val on = t in store.homeTags
                    store.homeTags = if (on) store.homeTags - t else store.homeTags + t
                    refreshHomeTags()
                    Toast.makeText(this, if (on) "#$t removed from Home" else "#$t added to Home", Toast.LENGTH_SHORT).show()
                }))
        }
    }

    private fun runSearch() {
        if (!::resultAdapter.isInitialized || !panelOpen) return
        val raw = input.text.toString(); val q = raw.trim().lowercase()
        searchJob?.cancel()
        val base = search.quick(raw, activeTag)
        resultAdapter.submit(base)
        if (q.length >= 2 && activeTag == null && !q.startsWith("#")) {
            searchJob = lifecycleScope.launch {
                delay(100)
                val extra = withContext(Dispatchers.IO) { search.extras(q) }
                if (extra.isNotEmpty()) resultAdapter.submit(search.merge(base, extra))
            }
        }
    }

    private fun openSearch(showKb: Boolean) {
        askPermsOnce()
        if (!panelOpen) {
            panelOpen = true
            panel.visibility = View.VISIBLE; panel.alpha = 0f; panel.translationY = dp(48).toFloat()
            panel.animate().alpha(1f).translationY(0f).setDuration(160).start()
            updateBars(); refreshTagRow(); runSearch()
        }
        if (showKb) { input.requestFocus(); WindowCompat.getInsetsController(window, input).show(WindowInsetsCompat.Type.ime()) }
    }

    private fun closeSearch() {
        if (!panelOpen) return
        panelOpen = false; searchJob?.cancel(); activeTag = null
        input.setText(""); input.clearFocus(); root.requestFocus()
        WindowCompat.getInsetsController(window, input).hide(WindowInsetsCompat.Type.ime())
        panel.animate().alpha(0f).translationY(dp(48).toFloat()).setDuration(140).withEndAction { if (!panelOpen) panel.visibility = View.GONE }.start()
        updateBars()
    }

    private fun askPermsOnce() {
        if (store.askedPerms) return
        store.askedPerms = true
        val p = mutableListOf(Manifest.permission.READ_CONTACTS)
        if (Build.VERSION.SDK_INT >= 33) p.addAll(listOf(Manifest.permission.READ_MEDIA_IMAGES, Manifest.permission.READ_MEDIA_VIDEO, Manifest.permission.READ_MEDIA_AUDIO))
        else p.add(Manifest.permission.READ_EXTERNAL_STORAGE)
        permLauncher.launch(p.toTypedArray())
    }

    private fun launchApp(a: AppEntry) {
        store.bump(a.key)
        try {
            startActivity(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER).setComponent(ComponentName(a.pkg, a.cls))
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED))
        } catch (e: Exception) { Toast.makeText(this, "Couldn't open ${a.label}", Toast.LENGTH_SHORT).show() }
    }

    private fun open(r: Row) {
        try {
            when (r) {
                is Row.App -> launchApp(r.app)
                is Row.Contact -> startActivity(Intent(Intent.ACTION_VIEW, r.uri))
                is Row.FileRow -> startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(r.uri, r.mime).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION))
                is Row.Setting -> startActivity(Intent(r.action))
                is Row.Web -> startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(store.searchUrl + Uri.encode(r.query))))
                is Row.Header -> return
            }
            closeSearch()
        } catch (e: Exception) { Toast.makeText(this, "Couldn't open that", Toast.LENGTH_SHORT).show() }
    }

    private fun appMenu(a: AppEntry) {
        val pinned = a.key in store.pinned
        val items = arrayOf(if (pinned) "Unpin from Home" else "Pin to Home", "Edit tags", "Hide from Snap", "App info", "Uninstall")
        AlertDialog.Builder(this).setTitle(a.label).setItems(items) { _, w ->
            when (w) {
                0 -> { store.pinned = if (pinned) store.pinned - a.key else store.pinned + a.key; refreshPinned() }
                1 -> editTags(a)
                2 -> { store.hidden = store.hidden + a.key; refreshAll() }
                3 -> startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${a.pkg}")))
                4 -> startActivity(Intent(Intent.ACTION_DELETE, Uri.parse("package:${a.pkg}")))
            }
        }.show()
    }

    private fun editTags(a: AppEntry) {
        val et = EditText(this).apply { setText(store.tagsOf(a.key).joinToString(", ")); hint = "work, banking, daily"; setSingleLine() }
        AlertDialog.Builder(this).setTitle("Tags for ${a.label}").setMessage("Separate with commas. Auto tags are added on top.")
            .setView(FrameLayout(this).apply { setPadding(dp(20), dp(8), dp(20), 0); addView(et) })
            .setPositiveButton("Save") { _, _ ->
                store.setTags(a.key, et.text.toString().split(",", "#", "\n").map { it.trim().lowercase() }.filter { it.isNotEmpty() }.distinct())
                refreshAll()
            }.setNegativeButton("Cancel", null).show()
    }

    private fun homeMenu() {
        AlertDialog.Builder(this).setItems(arrayOf("Snap settings", "Change wallpaper", "Rescan apps")) { _, w ->
            when (w) {
                0 -> startActivity(Intent(this, SettingsActivity::class.java))
                1 -> startActivity(Intent.createChooser(Intent(Intent.ACTION_SET_WALLPAPER), "Wallpaper"))
                2 -> reload()
            }
        }.show()
    }

    private fun pageHeader(title: String, vararg acts: Pair<String, () -> Unit>) = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(12), dp(8), dp(8), dp(8))
        addView(TextView(this@MainActivity).apply { text = title; textSize = 24f }, LinearLayout.LayoutParams(0, WRAP, 1f))
        for ((t, f) in acts) addView(TextView(this@MainActivity).apply {
            text = t; textSize = 14f; setPadding(dp(14), dp(8), dp(14), dp(8)); setOnClickListener { f() }
            layoutParams = LinearLayout.LayoutParams(WRAP, WRAP).apply { marginStart = dp(8) }
        })
    }

    private fun styleHeader(h: LinearLayout) {
        for (i in 0 until h.childCount) { val v = h.getChildAt(i) as TextView; v.setTextColor(textC); if (i > 0) v.background = pill(chipBg, dp(20)) }
    }

    private fun showPage(v: View) {
        if (page != null || panelOpen) return
        page = v; v.visibility = View.VISIBLE; v.alpha = 0f
        v.translationX = if (v === newsPage) dp(60).toFloat() else -dp(60).toFloat()
        v.animate().alpha(1f).translationX(0f).setDuration(180).start()
        if (v === newsPage) refreshNews(false) else renderWidgets()
        updateBars()
    }

    private fun closePage() {
        val v = page ?: return
        page = null
        v.animate().alpha(0f).translationX(if (v === newsPage) dp(60).toFloat() else -dp(60).toFloat()).setDuration(150)
            .withEndAction { if (page !== v) v.visibility = View.GONE }.start()
        updateBars()
    }

    private fun addWidgetFlow() {
        val ps = awm.installedProviders.sortedBy { it.loadLabel(packageManager).lowercase() }
        val names = ps.map { it.loadLabel(packageManager) + "  —  " + packageManager.getApplicationLabel(it.providerInfo.applicationInfo) }
        AlertDialog.Builder(this).setTitle("Add widget").setItems(names.toTypedArray()) { _, i -> bindWidget(ps[i]) }.show()
    }

    private fun bindWidget(p: AppWidgetProviderInfo) {
        val id = host.allocateAppWidgetId(); pendingId = id
        if (awm.bindAppWidgetIdIfAllowed(id, p.provider)) configureOrAdd(id)
        else startActivityForResult(Intent(AppWidgetManager.ACTION_APPWIDGET_BIND)
            .putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id).putExtra(AppWidgetManager.EXTRA_APPWIDGET_PROVIDER, p.provider), 78)
    }

    private fun configureOrAdd(id: Int) {
        val info = awm.getAppWidgetInfo(id)
        if (info?.configure != null) host.startAppWidgetConfigureActivityForResult(this, id, 0, 77, null) else addWidget(id)
    }

    private fun addWidget(id: Int) { store.widgets = store.widgets + id.toString(); renderWidgets() }

    private fun renderWidgets() {
        widgetBox.removeAllViews()
        for (s in store.widgets) {
            val id = s.toInt()
            val info = awm.getAppWidgetInfo(id)
            if (info == null) { store.widgets = store.widgets - s; continue }
            val wrap = FrameLayout(this)
            wrap.addView(host.createView(this, id, info), FrameLayout.LayoutParams(MATCH, maxOf(info.minHeight, dp(96))))
            wrap.addView(TextView(this).apply {
                text = "✕"; gravity = Gravity.CENTER; setTextColor(Color.WHITE); background = pill(0x99000000.toInt(), dp(16))
                setOnClickListener { host.deleteAppWidgetId(id); store.widgets = store.widgets - s; renderWidgets() }
            }, FrameLayout.LayoutParams(dp(32), dp(32), Gravity.END or Gravity.TOP).apply { topMargin = dp(4); marginEnd = dp(4) })
            widgetBox.addView(wrap, LinearLayout.LayoutParams(MATCH, WRAP).apply { bottomMargin = dp(12) })
        }
    }

    private fun refreshNews(force: Boolean) {
        if (articles.isEmpty()) articles = News.fromJson(store.newsCache)
        renderNews()
        if (store.sites.isEmpty() && store.topics.isEmpty()) return
        if (!force && articles.isNotEmpty() && System.currentTimeMillis() - store.newsFetched < 15 * 60_000L) return
        Toast.makeText(this, "Refreshing news…", Toast.LENGTH_SHORT).show()
        lifecycleScope.launch {
            val l = News.fetchAll(store)
            if (l.isEmpty()) { Toast.makeText(this@MainActivity, "No news fetched. Check internet or feeds.", Toast.LENGTH_SHORT).show(); return@launch }
            articles = l; store.newsCache = News.toJson(l); store.newsFetched = System.currentTimeMillis()
            renderNews()
        }
    }

    private fun renderNews() {
        newsTabs.removeAllViews()
        val dark = 0xFF101114.toInt()
        newsTabs.addView(chip("All", if (newsTopic == null) dark else textC, if (newsTopic == null) store.accent else chipBg, { newsTopic = null; renderNews() }))
        for (t in store.topics) {
            val sel = newsTopic == t
            newsTabs.addView(chip(t, if (sel) dark else textC, if (sel) store.accent else chipBg, { newsTopic = t; renderNews() },
                { store.topics = store.topics - t; if (newsTopic == t) newsTopic = null; renderNews() }))
        }
        val now = System.currentTimeMillis()
        val rows = News.forTopic(articles, newsTopic).take(80).map { a ->
            val ago = if (a.time > 0) DateUtils.getRelativeTimeSpanString(a.time, now, DateUtils.MINUTE_IN_MILLIS).toString() else ""
            Row.News(a, listOf(a.source, ago).filter { it.isNotEmpty() }.joinToString(" · "))
        }
        newsAdapter.submit(if (rows.isEmpty()) listOf(Row.Header("No news yet. Tap ⋯ to add websites and topics")) else rows)
    }

    private fun newsMenu() {
        AlertDialog.Builder(this).setItems(arrayOf("Add news website", "Add topic to track", "Remove a website")) { _, w ->
            when (w) {
                0 -> ask("Website or RSS link", "e.g. eenadu.net") { u -> addSite(u) }
                1 -> ask("Topic (long-press a tab to remove)", "e.g. Hyderabad metro, EV") { t ->
                    val x = t.trim()
                    if (x.isNotEmpty() && x !in store.topics) { store.topics = store.topics + x; refreshNews(true) }
                }
                2 -> AlertDialog.Builder(this).setItems(store.sites.toTypedArray()) { _, i -> store.sites = store.sites - store.sites[i]; refreshNews(true) }.show()
            }
        }.show()
    }

    private fun ask(title: String, hint: String, ok: (String) -> Unit) {
        val et = EditText(this).apply { this.hint = hint; setSingleLine() }
        AlertDialog.Builder(this).setTitle(title).setView(FrameLayout(this).apply { setPadding(dp(20), dp(8), dp(20), 0); addView(et) })
            .setPositiveButton("Add") { _, _ -> ok(et.text.toString()) }.setNegativeButton("Cancel", null).show()
    }

    private fun addSite(u: String) {
        Toast.makeText(this, "Finding feed…", Toast.LENGTH_SHORT).show()
        lifecycleScope.launch {
            val f = withContext(Dispatchers.IO) { News.discover(u) }
            if (f == null) Toast.makeText(this@MainActivity, "No RSS feed found. Paste the feed link directly.", Toast.LENGTH_LONG).show()
            else { if (f !in store.sites) store.sites = store.sites + f; refreshNews(true) }
        }
    }
}
