package com.snap.launcher

import android.Manifest
import android.content.ComponentName
import android.content.ContentResolver
import android.content.ContentUris
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.ContactsContract
import android.provider.MediaStore
import android.util.LruCache
import android.view.ViewGroup
import androidx.core.graphics.drawable.toBitmap
import org.json.JSONArray
import org.json.JSONObject

const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()
fun pill(color: Int, r: Int): GradientDrawable = GradientDrawable().apply { setColor(color); cornerRadius = r.toFloat() }

class Store(ctx: Context) {
    private val sp = ctx.applicationContext.getSharedPreferences("snap", Context.MODE_PRIVATE)
    var columns: Int get() = sp.getInt("columns", 4); set(v) { sp.edit().putInt("columns", v).apply() }
    var iconDp: Int get() = sp.getInt("iconDp", 52); set(v) { sp.edit().putInt("iconDp", v).apply() }
    var showLabels: Boolean get() = sp.getBoolean("labels", true); set(v) { sp.edit().putBoolean("labels", v).apply() }
    var accent: Int get() = sp.getInt("accent", 0xFF7C9CFF.toInt()); set(v) { sp.edit().putInt("accent", v).apply() }
    var theme: Int get() = sp.getInt("theme", 0); set(v) { sp.edit().putInt("theme", v).apply() }
    var keyboardOnSwipe: Boolean get() = sp.getBoolean("kb", false); set(v) { sp.edit().putBoolean("kb", v).apply() }
    var autoTags: Boolean get() = sp.getBoolean("auto", true); set(v) { sp.edit().putBoolean("auto", v).apply() }
    var askedPerms: Boolean get() = sp.getBoolean("asked", false); set(v) { sp.edit().putBoolean("asked", v).apply() }
    var searchUrl: String get() = sp.getString("url", "https://www.google.com/search?q=")!!; set(v) { sp.edit().putString("url", v).apply() }

    var sites: List<String> get() = list("sites"); set(v) = save("sites", v)
    var topics: List<String> get() = list("topics"); set(v) = save("topics", v)
    var widgets: List<String> get() = list("widgets"); set(v) = save("widgets", v)
    var gnews: Boolean get() = sp.getBoolean("gnews", true); set(v) { sp.edit().putBoolean("gnews", v).apply() }
    var newsCache: String get() = sp.getString("news", "[]")!!; set(v) { sp.edit().putString("news", v).apply() }
    var newsFetched: Long get() = sp.getLong("newsAt", 0L); set(v) { sp.edit().putLong("newsAt", v).apply() }

    private fun list(n: String): List<String> { val a = JSONArray(sp.getString(n, "[]")!!); return List(a.length()) { a.getString(it) } }
    private fun save(n: String, l: Collection<String>) { sp.edit().putString(n, JSONArray(l).toString()).apply() }
    var pinned: List<String> get() = list("pinned"); set(v) = save("pinned", v)
    var homeTags: List<String> get() = list("homeTags"); set(v) = save("homeTags", v)
    var hidden: Set<String> get() = list("hidden").toSet(); set(v) = save("hidden", v)

    private val tags = HashMap<String, List<String>>().also {
        val o = JSONObject(sp.getString("tags", "{}")!!)
        for (k in o.keys()) { val a = o.getJSONArray(k); it[k] = List(a.length()) { i -> a.getString(i) } }
    }
    private val counts = HashMap<String, Int>().also {
        val o = JSONObject(sp.getString("counts", "{}")!!)
        for (k in o.keys()) it[k] = o.getInt(k)
    }
    fun tagsOf(key: String): List<String> = tags[key] ?: emptyList()
    fun setTags(key: String, t: List<String>) {
        if (t.isEmpty()) tags.remove(key) else tags[key] = t
        val o = JSONObject(); for ((k, v) in tags) o.put(k, JSONArray(v))
        sp.edit().putString("tags", o.toString()).apply()
    }
    fun launches(key: String): Int = counts[key] ?: 0
    fun bump(key: String) {
        counts[key] = launches(key) + 1
        val o = JSONObject(); for ((k, v) in counts) o.put(k, v)
        sp.edit().putString("counts", o.toString()).apply()
    }
}

data class AppEntry(val label: String, val pkg: String, val cls: String, val category: Int) {
    val key: String = "$pkg/$cls"
    val lower: String = label.lowercase()
    val words: List<String> = lower.split(Regex("[^\\p{L}\\p{N}]+")).filter { it.isNotEmpty() }
    val initials: String = words.joinToString("") { it.take(1) }
}

class AppRepo(private val ctx: Context) {
    @Volatile var apps: List<AppEntry> = emptyList()
        private set
    private val icons = LruCache<String, Bitmap>(400)

    fun load() {
        val pm = ctx.packageManager
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val l = pm.queryIntentActivities(i, 0).map {
            AppEntry(it.loadLabel(pm).toString(), it.activityInfo.packageName, it.activityInfo.name, it.activityInfo.applicationInfo.category)
        }.sortedBy { it.lower }
        icons.evictAll()
        apps = l
        for (a in l) icon(a)
    }
    fun find(key: String): AppEntry? = apps.firstOrNull { it.key == key }
    fun icon(a: AppEntry): Bitmap {
        icons.get(a.key)?.let { return it }
        val pm = ctx.packageManager
        val d = try { pm.getActivityIcon(ComponentName(a.pkg, a.cls)) } catch (e: Exception) { pm.defaultActivityIcon }
        val b = d.toBitmap(160, 160)
        icons.put(a.key, b)
        return b
    }
}

sealed class Row {
    data class Header(val title: String) : Row()
    data class App(val app: AppEntry, val subtitle: String) : Row()
    data class Contact(val name: String, val number: String, val uri: Uri) : Row()
    data class FileRow(val name: String, val uri: Uri, val mime: String) : Row()
    data class Setting(val title: String, val action: String) : Row()
    data class Web(val query: String) : Row()
    data class News(val a: Article, val sub: String) : Row()
}

class Search(private val ctx: Context, private val repo: AppRepo, private val store: Store) {
    private val sets = listOf(
        Triple("Wi-Fi", "android.settings.WIFI_SETTINGS", "wifi internet network"),
        Triple("Bluetooth", "android.settings.BLUETOOTH_SETTINGS", "bluetooth pair"),
        Triple("Display", "android.settings.DISPLAY_SETTINGS", "display brightness screen dark"),
        Triple("Sound", "android.settings.SOUND_SETTINGS", "sound volume ringtone"),
        Triple("Battery saver", "android.settings.BATTERY_SAVER_SETTINGS", "battery power"),
        Triple("Location", "android.settings.LOCATION_SOURCE_SETTINGS", "location gps"),
        Triple("Apps", "android.settings.APPLICATION_SETTINGS", "apps manage"),
        Triple("Storage", "android.settings.INTERNAL_STORAGE_SETTINGS", "storage space"),
        Triple("Date & time", "android.settings.DATE_SETTINGS", "date time zone"),
        Triple("Accessibility", "android.settings.ACCESSIBILITY_SETTINGS", "accessibility"),
        Triple("Airplane mode", "android.settings.AIRPLANE_MODE_SETTINGS", "airplane flight"),
        Triple("Default apps", "android.settings.MANAGE_DEFAULT_APPS_SETTINGS", "default home launcher"),
        Triple("All settings", "android.settings.SETTINGS", "settings")
    )

    fun visibleApps(): List<AppEntry> { val h = store.hidden; return repo.apps.filter { it.key !in h } }

    private fun autoTag(a: AppEntry): String? = when (a.category) {
        ApplicationInfo.CATEGORY_GAME -> "games"
        ApplicationInfo.CATEGORY_AUDIO -> "music"
        ApplicationInfo.CATEGORY_VIDEO -> "video"
        ApplicationInfo.CATEGORY_IMAGE -> "photos"
        ApplicationInfo.CATEGORY_SOCIAL -> "social"
        ApplicationInfo.CATEGORY_NEWS -> "news"
        ApplicationInfo.CATEGORY_MAPS -> "maps"
        ApplicationInfo.CATEGORY_PRODUCTIVITY -> "work"
        else -> null
    }
    fun tagsFor(a: AppEntry): List<String> {
        val u = store.tagsOf(a.key)
        if (!store.autoTags) return u
        val t = autoTag(a)
        return if (t == null || t in u) u else u + t
    }
    fun allTags(): List<Pair<String, Int>> {
        val m = HashMap<String, Int>()
        for (a in visibleApps()) for (t in tagsFor(a)) m[t] = (m[t] ?: 0) + 1
        return m.entries.sortedWith(compareByDescending<Map.Entry<String, Int>> { it.value }.thenBy { it.key }).map { it.key to it.value }
    }

    private fun subseq(q: String, s: String): Boolean { var i = 0; for (c in s) if (i < q.length && c == q[i]) i++; return i == q.length }
    private fun score(q: String, a: AppEntry, tags: List<String>): Int {
        val l = a.lower
        var s = when {
            l == q -> 100
            l.startsWith(q) -> 90
            a.words.any { it.startsWith(q) } -> 80
            a.initials.startsWith(q) -> 70
            l.contains(q) -> 55
            q.length >= 2 && subseq(q, l) -> 30
            else -> 0
        }
        if (tags.any { it == q }) s = maxOf(s, 85) else if (tags.any { it.startsWith(q) }) s = maxOf(s, 50)
        if (s > 0) s += minOf(store.launches(a.key), 10)
        return s
    }

    private fun searchApps(raw: String, tag: String?): List<AppEntry> {
        var q = raw.trim().lowercase()
        var tp: String? = null
        if (q.startsWith("#")) { tp = q.substring(1); q = "" }
        val out = ArrayList<Pair<AppEntry, Int>>()
        for (a in visibleApps()) {
            val t = tagsFor(a)
            if (tag != null && tag !in t) continue
            if (tp != null && t.none { it.startsWith(tp) }) continue
            val s = if (q.isEmpty()) 1 else score(q, a, t)
            if (s > 0) out.add(a to s)
        }
        if (q.isEmpty()) return out.map { it.first }
        return out.sortedWith(compareByDescending<Pair<AppEntry, Int>> { it.second }.thenBy { it.first.lower }).map { it.first }
    }

    fun quick(raw: String, tag: String?): List<Row> {
        val q = raw.trim().lowercase()
        val rows = ArrayList<Row>()
        for (a in searchApps(raw, tag)) rows.add(Row.App(a, tagsFor(a).joinToString("  ") { "#$it" }))
        if (tag == null && q.isNotEmpty() && !q.startsWith("#")) {
            val s = if (q.length < 2) emptyList() else sets.filter { it.first.lowercase().contains(q) || it.third.contains(q) }
            if (s.isNotEmpty()) { rows.add(Row.Header("Settings")); s.forEach { rows.add(Row.Setting(it.first, it.second)) } }
            rows.add(Row.Web(raw.trim()))
        }
        return rows
    }

    fun merge(base: List<Row>, extra: List<Row>): List<Row> {
        val i = base.indexOfFirst { it !is Row.App }.let { if (it < 0) base.size else it }
        return base.take(i) + extra + base.drop(i)
    }

    private fun granted(p: String) = ctx.checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED
    private fun hasMedia() = if (Build.VERSION.SDK_INT >= 33)
        granted(Manifest.permission.READ_MEDIA_IMAGES) || granted(Manifest.permission.READ_MEDIA_VIDEO) || granted(Manifest.permission.READ_MEDIA_AUDIO)
    else granted(Manifest.permission.READ_EXTERNAL_STORAGE)

    fun extras(q: String): List<Row> {
        val out = ArrayList<Row>()
        val c = contacts(q); if (c.isNotEmpty()) { out.add(Row.Header("Contacts")); out.addAll(c) }
        val f = files(q); if (f.isNotEmpty()) { out.add(Row.Header("Files")); out.addAll(f) }
        return out
    }

    private fun contacts(q: String): List<Row> {
        if (!granted(Manifest.permission.READ_CONTACTS)) return emptyList()
        val P = ContactsContract.CommonDataKinds.Phone
        val args = Bundle().apply {
            putString(ContentResolver.QUERY_ARG_SQL_SELECTION, "${P.DISPLAY_NAME} LIKE ?")
            putStringArray(ContentResolver.QUERY_ARG_SQL_SELECTION_ARGS, arrayOf("%$q%"))
            putInt(ContentResolver.QUERY_ARG_LIMIT, 20)
        }
        val out = ArrayList<Row>(); val seen = HashSet<Long>()
        try {
            ctx.contentResolver.query(P.CONTENT_URI, arrayOf(P.DISPLAY_NAME, P.NUMBER, P.CONTACT_ID, P.LOOKUP_KEY), args, null)?.use { c ->
                while (c.moveToNext() && out.size < 5) {
                    val id = c.getLong(2)
                    if (!seen.add(id)) continue
                    out.add(Row.Contact(c.getString(0) ?: "", c.getString(1) ?: "", ContactsContract.Contacts.getLookupUri(id, c.getString(3))))
                }
            }
        } catch (e: Exception) { }
        return out
    }

    private fun files(q: String): List<Row> {
        if (!hasMedia()) return emptyList()
        val F = MediaStore.Files.FileColumns
        val base = MediaStore.Files.getContentUri("external")
        val args = Bundle().apply {
            putString(ContentResolver.QUERY_ARG_SQL_SELECTION, "${F.DISPLAY_NAME} LIKE ?")
            putStringArray(ContentResolver.QUERY_ARG_SQL_SELECTION_ARGS, arrayOf("%$q%"))
            putStringArray(ContentResolver.QUERY_ARG_SORT_COLUMNS, arrayOf(F.DATE_MODIFIED))
            putInt(ContentResolver.QUERY_ARG_SORT_DIRECTION, ContentResolver.QUERY_SORT_DIRECTION_DESCENDING)
            putInt(ContentResolver.QUERY_ARG_LIMIT, 6)
        }
        val out = ArrayList<Row>()
        try {
            ctx.contentResolver.query(base, arrayOf(F._ID, F.DISPLAY_NAME, F.MIME_TYPE), args, null)?.use { c ->
                while (c.moveToNext()) out.add(Row.FileRow(c.getString(1) ?: "", ContentUris.withAppendedId(base, c.getLong(0)), c.getString(2) ?: "*/*"))
            }
        } catch (e: Exception) { }
        return out
    }
}
