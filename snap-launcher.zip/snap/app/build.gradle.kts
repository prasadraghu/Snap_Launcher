plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android {
    namespace = "com.snap.launcher"
    compileSdk = 35
    defaultConfig { applicationId = "com.snap.launcher"; minSdk = 30; targetSdk = 35; versionCode = 1; versionName = "0.1" }
    signingConfigs { create("snap") { storeFile = file("snap.keystore"); storePassword = "snaplauncher"; keyAlias = "snap"; keyPassword = "snaplauncher" } }
    buildTypes { release { isMinifyEnabled = true; isShrinkResources = true; signingConfig = signingConfigs.getByName("snap")
        proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro") } }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
}
dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.activity:activity-ktx:1.9.3")
    implementation("androidx.recyclerview:recyclerview:1.3.2")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.7")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")
}
